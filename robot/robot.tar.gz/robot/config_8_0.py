# Please rename this file to config_80.py and adapt it to your needs

# Selenium

# Time till the next command is executed
SELENIUM_DELAY = 0

# How long a "Wait Until ..." command should wait
SELENIUM_TIMEOUT = 20
BROWSER = "ff"

# Odoo
SERVER = "localhost"
PORT = "8069"
ODOO_URL = "http://" + SERVER + ":" + PORT
ODOO_DB = "demo"
ODOO_USER = "admin"
ODOO_PASSWORD = "admin"

